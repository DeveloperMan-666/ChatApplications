#ifndef READ_IP_H_INCLUDED
#define READ_IP_H_INCLUDED
//IPv4 ��ַ . . . . . . . . . . . . : 192.168.3.19
int ReadIP()
{
    system("ipconfig > ipconfig_7ftn8c.txt");
    FILE *fp = NULL;
    if((fp = (fopen("ipconfig_7ftn8c.txt","r"))) == NULL)
    {
        printf("�ڲ����ϣ��볢��ʹ�ù���Ա��ʽ�򿪸�Ӧ�ó���\n");
        exit(1);
    }
    else
    {
        //char config[1000][10000];
        for(int i = 0;i < 14;i++)
        {
            if(i == 14)
            {
                int a,b;
                fscanf(fp,"IPv4 ��ַ . . . . . . . . . . . . : 192.168.%d.%d",a,b);
            }

        }

    }
    return "192.168.%d.%d",a,b;
}


#endif // READ_IP_H_INCLUDED
